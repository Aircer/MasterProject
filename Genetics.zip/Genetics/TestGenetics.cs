using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using NumSharp;
using MathNet.Numerics.LinearAlgebra;

namespace MapTileGridCreator.Core
{
	public class TestGenetics
	{
		public EvolutionaryAlgoParams algoParams;

		public GeneticAlgorithm ga;
		private System.Random random;
		private int numberTypeCells;
		private Vector3Int sizeDNA;
		private TypeParams[] typeParams;
		private CellInformation[] cellsInfos;

		public void StartGenetics(WaypointCluster cluster, EvolutionaryAlgoParams algoParams)
		{
			// Size of the DNA is size + 2 to have empty borders
			sizeDNA = new Vector3Int(cluster.size.x+2, cluster.size.y+2, cluster.size.z+2);
			random = new System.Random();
			numberTypeCells = cluster.cellInfos.Count;
			cellsInfos = cluster.cellInfos.ToArray();
			typeParams = new TypeParams[numberTypeCells + 1];
			this.algoParams = algoParams;

			SetTypeCellParams(cluster);

			ga = new GeneticAlgorithm(algoParams, sizeDNA, random, GetRandomType, FitnessFunction, cluster, typeParams);
		}

		private void SetTypeCellParams(WaypointCluster cluster)
		{
			typeParams[0] = new TypeParams();

			for (int i = 0; i < numberTypeCells; i++)
			{
				typeParams[i + 1] = cluster.cellInfos[i].typeParams;
			}
		}


		public void UpdateGenetics()
		{
			ga.NewGeneration();
		}

		public List<WaypointCluster> GetBestClusters(int nbSuggestions)
        {
			List<WaypointCluster> bestClusters = new List<WaypointCluster>();
			int j = 0;
			ga.ClassifyPopulation();
			for (int i = 0; i < nbSuggestions; i++)
			{
				if (j > 0)
					while (j < ga.oldPopulation.Length && ga.oldPopulation[j].Fitness == ga.oldPopulation[j - 1].Fitness)
						j++;

				if (j == ga.oldPopulation.Length)
					j = ga.oldPopulation.Length - 1;

				//UnityEngine.Debug.Log(ga.oldPopulation[j].Fitness + "  " +  j);
				bestClusters.Add(new WaypointCluster(ga.oldPopulation[j].sizeDNA, ga.oldPopulation[j].Genes, cellsInfos));
				j++;
			}

			return bestClusters;
		}

		private int GetRandomType()
		{
			return random.Next(numberTypeCells);
		}

		private float FitnessFunction(int index)
		{
			float finalScore = 0;
			float scoreX = 0f; float symTotalX = sizeDNA.x*sizeDNA.y*sizeDNA.z/2;
			DNA dna = ga.oldPopulation[index];

			//Debug.Log(dna.phenotype.walls_x.Count);
			
			for (int l = 1; l < sizeDNA.y-1; l++)
			{
				int k = sizeDNA.x - 1;
				for (int i = 0; i < sizeDNA.x / 2; i++, k--)
				{
					for (int j = 1; j < sizeDNA.z-1; j++)
					{
						if (dna.Genes[i][l][j].type == dna.Genes[k][l][j].type)
						{
								scoreX += 1;
						}
					}
				}
			}

			scoreX /= symTotalX;
			//scoreX = Mathf.Pow(2, scoreX) - 1;

			float scoreZ = 0f; int symTotalZ = sizeDNA.x * sizeDNA.y * sizeDNA.z/2;

			for (int l = 1; l < sizeDNA.y-1; l++)
			{
				int k = sizeDNA.z - 1;
				for (int i = 1; i < sizeDNA.z / 2; i++, k--)
				{
					for (int j = 1; j < sizeDNA.x-1; j++)
					{
						if (dna.Genes[j][l][i].type == dna.Genes[j][l][k].type)
						{
								scoreZ += 1;
						}
					}
				}
			}

			scoreZ /= symTotalZ;
			//scoreZ = Mathf.Pow(2, scoreZ) - 1;

			finalScore = Mathf.Pow(2, (scoreX + scoreZ) / 2) - 1;

			/*
			int nbWalls = dna.phenotype.walls_x.Count + dna.phenotype.walls_z.Count;
			int bigWalls = 0;

			foreach (Wall wallX in dna.phenotype.walls_x)
			{
				if (wallX.indexes.Count > 3) bigWalls++;
			}

			foreach (Wall wallZ in dna.phenotype.walls_z)
			{
				if (wallZ.indexes.Count > 3) bigWalls++;
			}
			
			if (nbWalls > 4)
				finalScore = finalScore/2;*/

			return finalScore;
		}
	}
}
