function [size, population, generations, numberRuns, candidatesNumber] = GetDataSetUp(IDExperiment)
    pathSetUp = strcat('D:\MasterProject\Genetic3\Data\Experiment_', num2str(IDExperiment), '\ExperimentSetUp.csv');
    [~,~,dataCommun] = xlsread(pathSetUp);
    dataSetUp = cell2mat(dataCommun(2,:));
    size = dataSetUp(1:3);
    population = dataSetUp(4);
    generations = dataSetUp(6);
    numberRuns = dataSetUp(8); 
    candidatesNumber = dataSetUp(14); 
end

