function fitness = GetFitness(IDExperiment, candidatesNumber, numberRuns, generations, population)
fitness = zeros(candidatesNumber, numberRuns, generations, population, 5);
path = strcat('D:\MasterProject\Genetic3\Data\Experiment_', num2str(IDExperiment));
for i=1:candidatesNumber
    
    pathFitness = strcat(path, '\Candidate', num2str(i-1), '\Fitness_');
    fitRun = zeros(generations*population, 5);

    % figure
    % hold on 
    for j = 1:numberRuns  
        [~,~,data] = xlsread(strcat(pathFitness, num2str(j - 1), '.csv'));
        fitRun(:, :) = cell2mat(data);

        for k = 1:generations  
            fitness(i, j, k, :, :) = fitRun((k-1)*population + 1:k*population, :);
        end
    end
end
end

