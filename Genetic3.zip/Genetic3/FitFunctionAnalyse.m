%% GET DATA FITNESS
clear all;
clc;

IDExperiment = 7;

[size, population, generations, numberRuns, candidatesNumber] = GetDataSetUp(IDExperiment);

Legend = GetLegend(candidatesNumber, IDExperiment);

fitness = GetFitness(IDExperiment, candidatesNumber, numberRuns, generations, population);

disp('GET DATA FITNESS done')
%% GET MEAN AND MAX

totalFitness = fitness(:, :, :, :, 1);
meanFitness = zeros(candidatesNumber, numberRuns, generations, 5);
maxFitness = zeros(candidatesNumber, numberRuns, generations, 5);

[M,I] = max(totalFitness,[], 4);
meanFitness(:, :, :, :) = mean(fitness, 4);

for i=1:candidatesNumber
    for j = 1:numberRuns  
        for k = 1:generations
            maxFitness(i, j, k, :) = fitness(i, j, k, I(i,j,k), :);
        end
    end
end

disp('GET MEAN AND MAX done')
%% PLOT TOTAL MAX FITNESS
lookGraph = ['b', 'r', 'k', 'm', 'y'];
x = 1:generations;

figure('Name','Max TotalFitness');

hold on
for i=1:candidatesNumber
    plotWConfidence(x, maxFitness(i, :, :, 1), numberRuns, lookGraph(i));
end
hold off

ylim([0 1])
xlabel('Number Generations') 
ylabel('Max TotalFitness') 
legend(Legend);
title('Max TotalFitness')

%% PLOT TOTAL MEAN FITNESS
lookGraph = ['b', 'r', 'k', 'm', 'y'];
x = 1:generations;

figure('Name','Mean TotalFitness');

hold on
for i=1:candidatesNumber
    plotWConfidence(x, meanFitness(i, :, :, 1), numberRuns, lookGraph(i));
end
hold off

ylim([0 1])
xlabel('Number Generations') 
ylabel('Mean TotalFitness') 
legend(Legend);
title('Mean TotalFitness')
%% PLOT ALL MAX FITNESS
figure('Name','Sub Max Fitness');

subplot(2,2,1)
hold on
for i=1:candidatesNumber
    plotWConfidence(x, maxFitness(i, :, :, 2), numberRuns, lookGraph(i));
end
hold off
ylim([0 1])
xlabel('Number Generations') 
ylabel('Max Fitness') 
title('Max Fitness Difference')

subplot(2,2,2)
hold on
for i=1:candidatesNumber
    plotWConfidence(x, maxFitness(i, :, :, 3), numberRuns, lookGraph(i));
end
hold off
ylim([0 1])
xlabel('Number Generations') 
ylabel('Max Fitness') 
title('Max Fitness Walking Area')

subplot(2,2,3)
hold on
for i=1:candidatesNumber
    plotWConfidence(x, maxFitness(i, :, :, 4), numberRuns, lookGraph(i));
end
hold off
ylim([0 1])
xlabel('Number Generations') 
ylabel('Max Fitness') 
title('Max Fitness Walls')

subplot(2,2,4)
hold on
for i=1:candidatesNumber
    plotWConfidence(x, maxFitness(i, :, :, 5), numberRuns, lookGraph(i));
end
hold off
ylim([0 1])
xlabel('Number Generations') 
ylabel('Max Fitness') 
title('Max Fitness Paths')

%% PLOT ALL MEAN FITNESS
figure('Name','Sub Mean Fitness');

subplot(2,2,1)
hold on
for i=1:candidatesNumber
    plotWConfidence(x, meanFitness(i, :, :, 2), numberRuns, lookGraph(i));
end
hold off
ylim([0 1])
xlabel('Number Generations') 
ylabel('Mean Fitness') 
title('Mean Fitness Difference')

subplot(2,2,2)
hold on
for i=1:candidatesNumber
    plotWConfidence(x, meanFitness(i, :, :, 3), numberRuns, lookGraph(i));
end
hold off
ylim([0 1])
xlabel('Number Generations') 
ylabel('Mean Fitness') 
title('Mean Fitness Walking Area')

subplot(2,2,3)
hold on
for i=1:candidatesNumber
    plotWConfidence(x, meanFitness(i, :, :, 4), numberRuns, lookGraph(i));
end
hold off
ylim([0 1])
xlabel('Number Generations') 
ylabel('Mean Fitness') 
title('Mean Fitness Walls')

subplot(2,2,4)
hold on
for i=1:candidatesNumber
    plotWConfidence(x, meanFitness(i, :, :, 5), numberRuns, lookGraph(i));
end
hold off
ylim([0 1])
xlabel('Number Generations') 
ylabel('Mean Fitness') 
title('Mean Fitness Paths')

