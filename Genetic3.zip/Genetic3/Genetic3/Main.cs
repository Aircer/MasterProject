﻿using System;
using System.Collections.Generic;
using UtilitiesGenetic;
using CsvHelper;
using System.IO;
using System.Globalization;
using Genetics;
using static Genetic3.Utilities;

namespace Genetic3
{
    public static class Program
    {
		public static string pathExperiment;
		public static string pathCandidates;

		public static int nbRuns;
		public static TypeParams[] typeParams;

		public static Fitness[][][][] fitness;
		public static Population[][][][] populations;

		private static int experimentID;
		private static EvolutionaryAlgoParams algoCommun;
		private static int typeSetUpCommun;
		private static Vector3Int sizeCommun;
		private static ObservedVariable variable;

		static void Main()
        {
			pathExperiment = "D:\\MasterProject\\Genetic3\\Data\\Experiment_";
			nbRuns = 5;
			typeParams = SetTypesParams();

			SetExperimentParams(ref experimentID, ref sizeCommun, ref algoCommun, ref typeSetUpCommun);
			variable = SetExperimentObservedVariable();

			Experiment exp = new Experiment(variable, experimentID, sizeCommun, algoCommun, typeSetUpCommun);

			fitness = new Fitness[exp.numberCandidates][][][];
			populations = new Population[exp.numberCandidates][][][];
			RunExperiment(nbRuns, exp, ref fitness, ref populations);

			WriteDataExperiment(pathExperiment, exp, nbRuns, fitness, populations);
		}

		private static void SetExperimentParams(ref int experimentID, ref Vector3Int sizeCommun,
										  ref EvolutionaryAlgoParams algoCommun, ref int typeSetUpCommun)
		{
			experimentID = 7;

			sizeCommun = new Vector3Int(5, 5, 5);

			algoCommun = new EvolutionaryAlgoParams();
			algoCommun.generations = 20;
			algoCommun.fitnessStop = 2f;
			algoCommun.mutationRate = 0.005f;
			algoCommun.population = 20;
			algoCommun.wDifference = 0f;

			algoCommun.elitism = 1;
			algoCommun.wWalkingAreas = 1f;
			algoCommun.wWallsCuboids = 1f;
			algoCommun.wPathfinding = 1f;

			typeSetUpCommun = Utilities.EMPTY;
		}

		private static ObservedVariable SetExperimentObservedVariable()
		{
			ObservedVariable variable = new ObservedVariable();
			variable.type = TypeObservedVariable.typeSetUp;

			variable.values = new float[2, 1];

			variable.values[0, 0] = 0;
			variable.values[1, 0] = 1;

			return variable;
		}

		private static TypeParams[] SetTypesParams()
		{
			int nbType = 5;
			TypeParams[] newTypesParams = new TypeParams[nbType];

			for (int i = 0; i < nbType; i++)
			{
				newTypesParams[i] = new TypeParams();
				newTypesParams[i].SetEmpty();
			}

			newTypesParams[0].door = true;
			newTypesParams[0].wall = true;

			newTypesParams[1].blockPath = true;
			newTypesParams[1].floor = true;
			newTypesParams[1].ground = true;

			newTypesParams[2].ladder = true;

			newTypesParams[3].blockPath = true;
			newTypesParams[3].ground = true;
			newTypesParams[3].stair = true;

			newTypesParams[4].blockPath = true;
			newTypesParams[4].wall = true;

			return newTypesParams;
		}

		private static void RunExperiment(int nbRuns, Experiment exp, ref Fitness[][][][] fitness, ref Population[][][][] populations)
		{
			for (int i = 0; i < exp.numberCandidates; i++)
			{
				Genetics.Init newInitGenetic = new Genetics.Init();
				newInitGenetic.GetSuggestionsClusters(exp.candidates[i].sizeDNA, typeParams, exp.candidates[i].wayPointsInit, nbRuns, exp.candidates[i].algoParams);

				fitness[i] = newInitGenetic.fitness;
				populations[i] = newInitGenetic.populations;
			}
		}

		private static void WriteDataExperiment(string pathExperiment, Experiment exp, int nbRuns, Fitness[][][][] fitness, Population[][][][] populations)
		{
			System.IO.Directory.CreateDirectory(pathExperiment + exp.experimentID);

			foreach (string pathFile in System.IO.Directory.GetFiles(pathExperiment + exp.experimentID))
			{
				System.IO.File.Delete(pathFile);
			}

			using (var w = new StreamWriter(pathExperiment + exp.experimentID + "\\" + "ExperimentSetUp.csv"))
			{
				var line = string.Format("Size_x; Size_y; Size_z; Population; Elitism; Generations; MutationRate; numberRuns; wDifference; wWalkingAreas; wWallsCuboids; wPathfinding; typeSetUp; numberCandidates");
				w.WriteLine(line);

				line = string.Format(sizeCommun.x + ";" + sizeCommun.y + ";" + sizeCommun.z + ";" + 
					algoCommun.population + ";" + algoCommun.elitism + ";" + algoCommun.generations + ";" + algoCommun.mutationRate + ";" + 
					nbRuns + ";" + algoCommun.wDifference + ";" + algoCommun.wWalkingAreas + ";" + algoCommun.wWallsCuboids + ";" +
					algoCommun.wPathfinding + ";" + typeSetUpCommun + ";" + variable.values.GetLength(0));
				w.WriteLine(line);

				line = string.Format(variable.type.ToString());
				w.WriteLine(line);

				for (int i = 0; i < variable.values.GetLength(0); i++)
				{
					line = "";
					for (int j = 0; j < variable.values.GetLength(1); j++)
					{
						if (variable.type == TypeObservedVariable.typeSetUp)
						{
							if(variable.values[i, j] == Utilities.EMPTY)
								line += string.Format("empty ;");
							if (variable.values[i, j] == Utilities.SIMPLE)
								line += string.Format("simple ;");
							if (variable.values[i, j] == Utilities.CHAOS)
								line += string.Format("chaos ;");
						}
						else
							line += string.Format(variable.values[i, j] + ";");
					}
					w.WriteLine(line);
				}

				w.Flush();
			}

			for (int i = 0; i < exp.numberCandidates; i++)
			{
				string pathCandidate = pathExperiment + exp.experimentID + "\\Candidate" + i;
				Data.Write(exp.candidates[i], pathCandidate, nbRuns, fitness[i], populations[i]);
			}
		}
	}
}
