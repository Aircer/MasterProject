﻿using System;
using System.Collections.Generic;
using UtilitiesGenetic;
using CsvHelper;
using System.IO;
using System.Globalization;
using Genetics;

namespace Genetic3
{
    public static class Utilities
    {
		public const int EMPTY = 0;
		public const int SIMPLE = 1;
		public const int CHAOS = 2;

		public enum TypeSetUp
		{
			Empty, Simple, Chaos
		};

		public enum TypeObservedVariable 
		{
			size, typeSetUp, elitism, population, mutationRate, wDifference, wWalkingAreas, wWallsCuboids, wPathfinding
		};

		public struct ObservedVariable
		{
			public TypeObservedVariable type;
			public float[,] values;
		};
	}
}
