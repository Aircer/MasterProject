﻿using System;
using System.Collections.Generic;
using UtilitiesGenetic;
using CsvHelper;
using System.IO;
using System.Globalization;
using Genetics;
using Genetic3;
using static Genetic3.Program;
using static Genetic3.Utilities;

namespace Genetic3
{
	public class Experiment
	{
		public int numberCandidates;
		public Candidate[] candidates;
		public int experimentID;

		private int[,,] randomInt;

		private Vector3Int[] sizeGrid;
		private EvolutionaryAlgoParams[] algoParams;
		private int[] typeSetUp;

		public Experiment(ObservedVariable variable, int ID, Vector3Int sizeGridCommun, EvolutionaryAlgoParams algoParamsCommun, int typeSetUpCommun)
		{
			randomInt = RandomInt(new System.Random());

			numberCandidates = variable.values.GetLength(0);
			experimentID = ID; 

			sizeGrid = SetSize(numberCandidates, sizeGridCommun, variable);
			algoParams = SetAlgoParams(numberCandidates, algoParamsCommun, variable);
			typeSetUp = SetTypeSetUp(numberCandidates, typeSetUpCommun, variable);

			candidates = SetCandidates(numberCandidates, sizeGrid, algoParams, typeSetUp, randomInt);
		}


		private int[,,] RandomInt(System.Random rand)
		{
			int[,,] randomInt = new int[100, 100, 100];

			for (int x = 0; x < 100; x++)
			{
				for (int y = 0; y < 100; y++)
				{
					for (int z = 0; z < 100; z++)
					{
						randomInt[x, y, z] = rand.Next(0, typeParams.Length + 1);
					}
				}
			}

			return randomInt;
		}

		private Vector3Int[] SetSize(int numberCandidates, Vector3Int sizeCommun, ObservedVariable variable)
		{
			Vector3Int[] size = new Vector3Int[numberCandidates];

			for (int i = 0; i < numberCandidates; i++)
			{
				if(variable.type != TypeObservedVariable.size)
					size[i] = new Vector3Int(sizeCommun.x, sizeCommun.y, sizeCommun.z);
				else
					size[i] = new Vector3Int((int)variable.values[i, 0], (int)variable.values[i, 1], (int)variable.values[i, 2]);
			}

			return size;
		}

		private EvolutionaryAlgoParams[] SetAlgoParams(int numberCandidates, EvolutionaryAlgoParams algoCommun, ObservedVariable variable)
		{
			EvolutionaryAlgoParams[] algoParams = new EvolutionaryAlgoParams[numberCandidates];

			for (int i = 0; i < numberCandidates; i++)
			{
				algoParams[i].generations = algoCommun.generations;
				algoParams[i].fitnessStop = algoCommun.fitnessStop;

				if (variable.type != TypeObservedVariable.elitism)
					algoParams[i].elitism = algoCommun.elitism;
				else
					algoParams[i].elitism = (int)variable.values[i, 0];

				if (variable.type != TypeObservedVariable.population)
					algoParams[i].population = algoCommun.population;
				else
					algoParams[i].population = (int)variable.values[i, 0];

				if (variable.type != TypeObservedVariable.mutationRate)
					algoParams[i].mutationRate = algoCommun.mutationRate;
				else
					algoParams[i].mutationRate = variable.values[i, 0];



				if (variable.type != TypeObservedVariable.wDifference)
					algoParams[i].wDifference = algoCommun.wDifference;
				else
					algoParams[i].wDifference = variable.values[i, 0];

				if (variable.type != TypeObservedVariable.wWalkingAreas)
					algoParams[i].wWalkingAreas = algoCommun.wWalkingAreas;
				else
					algoParams[i].wWalkingAreas = variable.values[i, 0];

				if (variable.type != TypeObservedVariable.wWallsCuboids)
					algoParams[i].wWallsCuboids = algoCommun.wWallsCuboids;
				else
					algoParams[i].wWallsCuboids = variable.values[i, 0];

				if (variable.type != TypeObservedVariable.wPathfinding)
					algoParams[i].wPathfinding = algoCommun.wPathfinding;
				else
					algoParams[i].wPathfinding = variable.values[i, 0];
			}

			return algoParams;
		}

		private int[] SetTypeSetUp(int numberCandidates, int typeSetUpCommun, ObservedVariable variable)
		{
			int[] typeSetUp = new int[numberCandidates];

			for (int i = 0; i < numberCandidates; i++)
			{
				if(variable.type != TypeObservedVariable.typeSetUp)
					typeSetUp[i] = typeSetUpCommun;
				else
					typeSetUp[i] = (int)variable.values[i, 0];
			}

			return typeSetUp;
		}

		private Candidate[] SetCandidates(int numberCandidates, Vector3Int[] sizeGrid, 
			EvolutionaryAlgoParams[] algoParams, int[] typeSetUp, int[,,] randomInt)
		{
			Candidate[] candidates = new Candidate[numberCandidates];
			for (int i = 0; i < numberCandidates; i++)
			{
				candidates[i] = new Candidate(randomInt, sizeGrid[i], typeSetUp[i], algoParams[i]);
			}

			return candidates;
		}
	}

	public class Candidate
	{
		public Vector3Int sizeGrid;
		public Vector3Int sizeDNA;
		public int[][][] wayPointsInit;
		public EvolutionaryAlgoParams algoParams;
		public int typeSetUp;
		public int numberCandidates;

		public Candidate(int[,,] randomInt, Vector3Int size_grid, int typeSU, EvolutionaryAlgoParams algo)
		{
			sizeGrid = size_grid;
			sizeDNA = new Vector3Int(sizeGrid.x + 2, sizeGrid.y + 2, sizeGrid.z + 2);

			typeSetUp = typeSU;
			algoParams = algo;

			wayPointsInit = SetWaypointsParams(typeSetUp, randomInt);
		}

		private int[][][] SetWaypointsParams(int typeSetUp, int[,,] randomInt)
		{
			int[][][] waypointsParamsXYZ = new int[sizeDNA.x][][];

			for (int x = 0; x < sizeDNA.x; x++)
			{
				int[][] waypointsParamsYZ = new int[sizeDNA.y][];
				for (int y = 0; y < sizeDNA.y; y++)
				{
					int[] waypointsParamsZ = new int[sizeDNA.z];
					for (int z = 0; z < sizeDNA.z; z++)
					{
						if (x == 0 || y == 0 || z == 0
						|| x == sizeDNA.x - 1 || y == sizeDNA.y - 1 || z == sizeDNA.z - 1)
							waypointsParamsZ[z] = 0;
						else
						{
							if (typeSetUp == Utilities.EMPTY || typeSetUp == Utilities.SIMPLE)
								waypointsParamsZ[z] = 0;
							if (typeSetUp == Utilities.CHAOS)
								waypointsParamsZ[z] = randomInt[x, y, z];
						}
					}
					waypointsParamsYZ[y] = waypointsParamsZ;
				}
				waypointsParamsXYZ[x] = waypointsParamsYZ;
			}

			if (typeSetUp == Utilities.SIMPLE)
			{
				for (int x = 1; x < sizeDNA.x - 1; x++)
				{
					for (int z = 1; z < sizeDNA.z - 1; z++)
					{
						waypointsParamsXYZ[x][1][z] = 2;
					}
				}

				for (int y = 1; y < sizeDNA.y - 1; y++)
				{
					for (int z = 1; z < sizeDNA.z - 1; z++)
					{
						waypointsParamsXYZ[sizeDNA.x/2][y][z] = 5;
					}
				}
			}

			return waypointsParamsXYZ;
		}
	}
}
