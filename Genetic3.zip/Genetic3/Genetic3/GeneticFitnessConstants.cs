﻿using System.Collections.Generic;
using System.Linq;
using System;
using UtilitiesGenetic;

public static class FitnessConstants
{
	public static int WALL_WIDTH_MAX = 1;
	public static int WALL_LENGTH_MIN = 2;
	public static int WALL_HEIGHT_MIN = 2;

	public static int WA_SIZE_MIN = 3;
}