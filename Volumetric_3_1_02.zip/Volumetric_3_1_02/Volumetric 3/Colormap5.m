function [ ] = Colormap5( )
%COLORMAP5 Summary of this function goes here
%   Detailed explanation goes here

    [UpdateVols, UpdateColor, UpdateAlpha] = ViewWindow();
    
    

end

