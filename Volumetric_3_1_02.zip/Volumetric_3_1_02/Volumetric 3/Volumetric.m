function [  ] = Volumetric( )

    AddThisPath(); % Dangerous but I'll Deal with Later
    AddOldTools(); % Need to re-write these like the plague but they work
    
    %Silly splash page for people to look at
    SplashWindow();
    
    LayerWindow([]);
    
    


end

