%Author: James W. Ryland
%June 14, 2012

function [ output_args ] = SmallRenderWindow(  )
%SMALLRENDERWINDOW Summary of this function goes here
%   Detailed explanation goes here


end
