function [ ] = testGUI(  )
%TESTGUI Summary of this function goes here
%   Detailed explanation goes here
    
    LayersWindow([],'TEST GUI');
    
end
